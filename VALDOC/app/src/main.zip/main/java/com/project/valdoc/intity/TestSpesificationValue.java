package com.project.valdoc.intity;

/**
 * Created by Avinash on 2/28/2016.
 */
public class TestSpesificationValue {
    public String test_specific_value;
    public int test_specific_id;
    public String test_detail_id;
    public String fieldName;
    public String fieldValue;

    public String getTest_specific_value() {
        return test_specific_value;
    }

    public void setTest_specific_value(String test_specific_value) {
        this.test_specific_value = test_specific_value;
    }

    public int getTest_specific_id() {
        return test_specific_id;
    }

    public void setTest_specific_id(int test_specific_id) {
        this.test_specific_id = test_specific_id;
    }

    public String getTest_detail_id() {
        return test_detail_id;
    }

    public void setTest_detail_id(String test_detail_id) {
        this.test_detail_id = test_detail_id;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public String getFieldValue() {
        return fieldValue;
    }

    public void setFieldValue(String fieldValue) {
        this.fieldValue = fieldValue;
    }
}
