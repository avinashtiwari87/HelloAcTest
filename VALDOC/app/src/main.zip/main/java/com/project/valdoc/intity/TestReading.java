package com.project.valdoc.intity;

/**
 * Created by Avinash on 2/28/2016.
 */
public class TestReading {
    private String testreading;
    private int testReadingID;
    public int test_detail_id;
    public String entityName;
    public String value;

    public String getTestreading() {
        return testreading;
    }

    public void setTestreading(String testreading) {
        this.testreading = testreading;
    }

    public int getTestReadingID() {
        return testReadingID;
    }

    public void setTestReadingID(int testReadingID) {
        this.testReadingID = testReadingID;
    }

    public int getTest_detail_id() {
        return test_detail_id;
    }

    public void setTest_detail_id(int test_detail_id) {
        this.test_detail_id = test_detail_id;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
