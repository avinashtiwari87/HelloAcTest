package com.project.valdoc;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class SplashActivity extends AppCompatActivity {
    Spinner testAreaSpiner, equipmentSpinner, ahuSpinner, roomSpinner, fillingRoomSpinner;
    List<String> areaTestList, equipmentTestList, ahuTestList, roomTestList, fillingRoomTestList;
    ArrayAdapter<String> areaAdapter,equipmentAdapter,ahuAdapter,roomAdapter,fillingRoomAdapter;
    Button submit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        spinerInitialization();
        listItemCreation();
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
//Spinner Initialization
        spinnerCreation();
        initButton();
    }

    private void initButton() {
        submit=(Button)findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(SplashActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_splash, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void spinerInitialization() {
        testAreaSpiner = (Spinner) findViewById(R.id.testareaspiner);
        equipmentSpinner = (Spinner) findViewById(R.id.equipmentspinner);
        ahuSpinner = (Spinner) findViewById(R.id.ahuspinner);
        roomSpinner = (Spinner) findViewById(R.id.roomspinner);
        fillingRoomSpinner = (Spinner) findViewById(R.id.fillingroomspinner);
    }

    public void listItemCreation() {
        areaTestList = new ArrayList<String>();
        areaTestList.add("SFF");
        areaTestList.add("OTL");
        areaTestList.add("BLD");
        areaTestList.add("KRSG");

        equipmentTestList = new ArrayList<String>();
        equipmentTestList.add("EQUIPMENT");
        equipmentTestList.add("AHU");

        ahuTestList = new ArrayList<String>();
        ahuTestList.add("AHU1");
        ahuTestList.add("AHU2");
        ahuTestList.add("AHU3");
        ahuTestList.add("AHU4");

        roomTestList = new ArrayList<String>();
        roomTestList.add("FILLINGROOM1");
        roomTestList.add("FILLINGROOM2");
        roomTestList.add("FILLINGROOM3");
        roomTestList.add("FILLINGROOM4");

        fillingRoomTestList = new ArrayList<String>();
        fillingRoomTestList.add("Airvelocitytest");
        fillingRoomTestList.add("test2");
        fillingRoomTestList.add("test3");
        fillingRoomTestList.add("test4");
    }

    public void spinnerCreation() {



        areaAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, areaTestList);
        equipmentAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, equipmentTestList);
        ahuAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, ahuTestList);
        roomAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, roomTestList);
        fillingRoomAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, fillingRoomTestList);

        testAreaSpiner.setAdapter(areaAdapter);
        equipmentSpinner.setAdapter(equipmentAdapter);
        ahuSpinner.setAdapter(ahuAdapter);
        roomSpinner.setAdapter(roomAdapter);
        fillingRoomSpinner.setAdapter(fillingRoomAdapter);

        testAreaSpiner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                // TODO Auto-generated method stub

                Toast.makeText(getBaseContext(), areaTestList.get(arg2),
                        Toast.LENGTH_SHORT).show();
            }

            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });

        equipmentSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                // TODO Auto-generated method stub

                Toast.makeText(getBaseContext(), equipmentTestList.get(arg2),
                        Toast.LENGTH_SHORT).show();
            }

            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });

        ahuSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                // TODO Auto-generated method stub

                Toast.makeText(getBaseContext(), ahuTestList.get(arg2),
                        Toast.LENGTH_SHORT).show();
            }

            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });
        roomSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                // TODO Auto-generated method stub

                Toast.makeText(getBaseContext(), roomTestList.get(arg2),
                        Toast.LENGTH_SHORT).show();
            }

            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });

        fillingRoomSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                // TODO Auto-generated method stub

                Toast.makeText(getBaseContext(), fillingRoomTestList.get(arg2),
                        Toast.LENGTH_SHORT).show();
            }

            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });


    }
}
